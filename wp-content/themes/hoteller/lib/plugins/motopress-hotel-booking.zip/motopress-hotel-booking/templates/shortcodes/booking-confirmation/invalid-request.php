<?php
if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<p>
	<?php _e( 'Invalid request.', 'motopress-hotel-booking' ); ?>
</p>
