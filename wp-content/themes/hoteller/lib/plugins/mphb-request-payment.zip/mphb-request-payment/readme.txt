﻿=== Hotel Booking Payment Request ===
Contributors: MotoPress
Donate link: https://motopress.com/
Tags: hotel booking, payment request
Requires at least: 4.6
Tested up to: 5.2
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Send your clients a payment link, which redirects them to an online checkout page to pay the booking balance or the full balance in advance.

== Description ==
Send your clients a payment link, which redirects them to an online checkout page to pay the booking balance or the full balance in advance.

== Installation ==

1. Upload the MotoPress plugin to the /wp-content/plugins/ directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.


== Copyright ==

Hotel Booking Payment Request, Copyright (C) 2019, MotoPress https://motopress.com/
Hotel Booking Payment Request plugin is distributed under the terms of the GNU GPL.


== Changelog ==

= 1.1.1, Sep 3 2019 =
* Improved compatibility with Hotel Booking plugin.

= 1.1.0, Jun 25 2019 =
* Fixed the issue of displaying incorrect price in price breakdown in case of the price change.

= 1.0.2, Apr 3 2019 =
* Improved compatibility with WPML plugin.

= 1.0.1, Feb 8 2019 =
* Fixed the issue with the payment form.

= 1.0.0, Dec 2018 =
* Initial release
