<?php

/**
 *
 * @param string $version version to compare with wp version
 * @param string $operator Optional. Possible operators are: <, lt, <=, le, >, gt, >=, ge, ==, =, eq, !=, <>, ne respectively. Default =.
  This parameter is case-sensitive, values should be lowercase.
 * @return bool
 */
function mphbw_is_wp_version( $version, $operator = '=' ){
	global $wp_version;
	return version_compare( $wp_version, $version, $operator );
}

/**
 * Check is plugin active.
 *
 * @param string $pluginSubDirSlashFile
 * @return bool
 */
function mphbw_is_plugin_active( $pluginSubDirSlashFile ){
	if ( !function_exists( 'is_plugin_active' ) ) {
		/**
		 * Detect plugin. For use on Front End only.
		 */
		include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
	}
	return is_plugin_active( $pluginSubDirSlashFile );
}

/**
 *
 * @return \MPHBW\Plugin
 */
function MPHBW(){
	return \MPHBW\Plugin::getInstance();
}
